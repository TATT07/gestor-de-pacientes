<?php
// index.php - Redirección automática a la interfaz principal
header('Location: frontend/');
exit;
?>